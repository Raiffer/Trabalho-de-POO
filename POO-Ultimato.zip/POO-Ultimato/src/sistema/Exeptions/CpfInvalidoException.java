package sistema.Exeptions;
import java.lang.Exception;

// Exceção para caso o CPF digitado não esteja no formato desejado
public class CpfInvalidoException extends Exception {
    public CpfInvalidoException(String message) {
        super(message);
    }
}
