package sistema.Exeptions;
import java.lang.Exception;

// Exceção para caso o email não esteja no formarto desejado
public class EmailInvalidoException extends Exception {
    public EmailInvalidoException(String message) {
        super(message);
    }
}
