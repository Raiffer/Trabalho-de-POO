package sistema.Exeptions;
import java.lang.Exception;

// Exceção para caso a atividade pesquisada não esteja cadastrada no sistema
public class AtividadeNaoEncontradaException extends Exception {
    public AtividadeNaoEncontradaException(String message) {
        super(message);
    }
}
