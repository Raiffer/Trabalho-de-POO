package sistema.Exeptions;
import java.lang.Exception;

// Exceção para caso o evento pesquisado não esteja cadastrado no sistema
public class EventoNaoEncontradoException extends Exception {
    public EventoNaoEncontradoException(String message) {
        super(message);
    }
}