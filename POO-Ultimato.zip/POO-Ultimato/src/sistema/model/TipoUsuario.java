package sistema.model;

public enum TipoUsuario {
	ORGANIZADOR, PARTICIPANTE, PALESTRANTE;
}
