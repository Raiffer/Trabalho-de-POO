package sistema.model;

import java.util.HashMap;
import java.util.Map;
//Alguns atributos nao tem setters pois nao podem ser mudados.

// Atributos e métodos da entidade Evento
// Esta classe é o foco do sistema, pois os eventos que serão cadastrados e realizados a partir deste programa

public class Evento {
	private String nome, local, dataInicio, dataFim;
	private double notaMedia;
	private Map<String, Usuario> participantes = new HashMap<>();
	private Map<String, Atividade> atividades = new HashMap<>();
	private Usuario organizador;

	public Evento(String nome, String local, String dataInicio, String dataFim, Usuario organizador) {
		this.nome = nome;
		this.local = local;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
		this.organizador = organizador;
		this.notaMedia = 0;
	}

	public String getNome() {
		return nome;
	}

	public void setnomeEvento(String nome) {
		this.nome = nome;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}


	public HashMap<String, Usuario> getParticipantes() {
		return (HashMap<String, Usuario>) participantes;
	}

	public Usuario getOrganizador() {
		return organizador;
	}

	public String getParticipante(String email) {
		return participantes.get(email).getNome();
	}


	public String getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio;
	}

	public String getDataFim() {
		return dataFim;
	}

	public void setDataFim(String dataFim) {
		this.dataFim = dataFim;
	}

	public void guardarUsuario(Usuario usuario){
		participantes.put(usuario.getEmail(),usuario);
	}
	
	public void guardarAtividade(Atividade atividade) {
		atividades.put(atividade.getNomeAtv(), atividade);
	}

}