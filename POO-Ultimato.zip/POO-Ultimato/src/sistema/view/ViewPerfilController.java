package sistema.view;

import sistema.model.Model;

import java.io.IOException;

//CONTROLLER DE PERFIL
public class ViewPerfilController {
    private Model model;
    private ViewPerfil view;

    //INICIALIZADOR
    public void initViewPerfilController(Model model, ViewPerfil view) {
        this.model = model;
        this.view = view;
    }

    //INTERAJE COM A VIEW
    public void interacao(int caso) throws IOException {
        switch (caso){
            case 1: view.menu(); break;//ABRE A INTERFACE
            case 2: view.goEditarPerfil(); break;//VAI PARA A TELA DE EDICAO DE PERFIL
            case 3: model.deletarUsuario(view.getEmail());//DELETA O USUARIO
                view.goLogin();
                break;
            case 4: view.goMenu(); break;//VAI PARA A TELA DE MENU
            case 5:
                view.mensagem("");
                view.mensagem("Opcao Invalida!");//AVISA EM CASO DE ERRO
                view.mensagem("");
                view.menu();
                break;
            case 6: view.goLogin(); break;
        }
    }



}