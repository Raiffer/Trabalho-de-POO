package sistema.view;

import sistema.model.*;
import sistema.Exeptions.EventoNaoEncontradoException;
import java.io.IOException;
import java.util.Scanner;

//Menu do sistema
public class ViewMenu {
	private ViewMenuController controller;
	private Model model;
	private String email, evento;

	//Metodo inicializador do Objeto
    public void initViewMenu(String email, Model model) throws IOException {
		this.model = model;
		this.email = email;
		controller = new ViewMenuController();
		controller.initViewMenuController(model, this);
		controller.interacao(6);
	}

	//Abre a Interface
	public void menu() throws IOException {
		Scanner sc = new Scanner(System.in);
		String escolha;
		System.out.println("Menu Principal");
		System.out.println("1 - Ver Lista de Eventos");
		System.out.println("2 - Ver Perfil");
		System.out.println("3 - Criar Evento");
		System.out.println("4 - Pesquisar Evento");
		System.out.println("5 - Desconectar");
		escolha = sc.nextLine();
		switch (escolha) {
			case "1": controller.interacao(1); break;
			case "2": controller.interacao(2); break;
			case "3": controller.interacao(3); break;
			case "4": controller.interacao(4); break;
			case "5": controller.interacao(5); break;
			default: controller.interacao(8);
		}
	}


	//Pesquisa evento
	public void pesquisarEvento() throws IOException, EventoNaoEncontradoException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o nome do evento: ");
		evento = sc.nextLine();
        if (model.verificarEvento(evento)){
            controller.interacao(7);
        }else{
			throw new EventoNaoEncontradoException("Evento nao Encontrado");
		}
    }

	//Vai para a tela do evento selecionado
	public void goEvento() throws IOException{
		ViewEvento viewEvento = new ViewEvento();
		viewEvento.initViewEvento(email, model, evento);
	}

	//Vai para a tela do perfil
	public void goPerfil() throws IOException {
		ViewPerfil viewPerfil = new ViewPerfil();
		viewPerfil.initViewPerfil(model, email);
	}

	//Vai para a tela de criacao de evento
	public void goCriarEvento() throws IOException{
		ViewCriarEvento viewCriarEvento = new ViewCriarEvento();
		viewCriarEvento.initViewCriarEvento(model, email);
	}

	public String getEvento(){
		return evento;
	}

	//Volta para o inicio
	public void goLogin(Model model) throws IOException {
		ViewLogin viewLogin = new ViewLogin();
		viewLogin.initViewLogin(model);
	}
	public String getEmail() {
		return email;
	}

	//mostra na tela uma mensagem, requistado pelo controller
	public void mensagem(String mensagem) {
		System.out.println(mensagem);
	}
}
