package sistema.view;

import sistema.model.*;

import java.io.IOException;

//Classe controller da tela de criacao de eventos
public class ViewCriarEventoController {
    private ViewCriarEvento view;
    private Model model;

    //Inicializa o objeto
    public void initViewCriarEventoController(Model model, ViewCriarEvento view) {
        this.model = model;
        this.view = view;
    }

    //Metodo de Interacao com a View
    public void interacao(int caso) throws IOException {
        switch (caso) {
            case 1:
                view.menu();//Abre a interface da tela
                break;
            case 2:
                view.criarEvento();//Ativa o metodo que recebera as informacoes
                break;
            case 3:
                view.goMenu();//Volta para a tela de menu
                break;
            case 4:
                view.mensagem("");
                view.mensagem("Opcao Invalida!");//Alerta caso tenha sido feita uma operacao ilegal
                view.mensagem("");
                view.menu();
                break;
            case 5: //Recebe e armazena as informacoes do evento
                view.setNome();
                view.setLocal();
                view.setDataInicio();
                view.setDataFim();
                model.criarEvento(view.getNome(),view.getLocal(),view.getDataInicio(), view.getDataFim(), view.getEmail());
                view.goMenu();
                break;
            case 6://Valida nome
                if(view.getNome().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Nome Invalido");
                    view.setNome();
                }
                break;
            case 7://Valida local
                if(view.getLocal().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Local Invalido");
                    view.setLocal();
                }
                break;
            case 8://Valida data de inicio
                if(view.getDataInicio().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Data Invalida");
                    view.setDataInicio();
                }
                break;
            case 9://Valida data de fim
                if(view.getDataFim().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Data Invalido");
                    view.setDataFim();
                }
                break;
        }
    }
}