package sistema.view;

import sistema.model.Model;

import java.io.IOException;

// Controlador da tela de Criacao de atividade
public class ViewCriarAtividadeController {
    private ViewCriarAtividade view;
    private Model model;

    //Inicializa o Objeto
    public void initViewCriarAtividadeController(Model model, ViewCriarAtividade view) {
        this.model = model;
        this.view = view;
    }

    //Metodo de interacao com a View
    public void interacao(int caso) throws IOException {
        switch (caso) {
            case 0:
                view.menu();//Cria a interface da tela
                break;
            case 1:
                view.criarAtividade(); //Ativa o metodo que ira receber as credencias
                break;
            case 2:
                view.goEvento(); //Volta para a tela do evento
                break;
            case 3:
                view.mensagem("");
                view.mensagem("Opcao Invalida!");//Avisa caso tenha sido usada uma operacao ilegal
                view.mensagem("");
                break;
            case 4://Recebe e armazena os dados da atividade
                view.setNome();
                view.setData();
                view.setHoraInicio();
                view.setHoraFim();
                model.criarAtividade(view.getNome(), view.getData(), view.getHoraInicio(), view.getHoraFim(), view.getEvento());
                view.goEvento();
                break;
            case 5:
                if(view.getNome().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Nome Invalido");
                    view.setNome();
                }
                break;
            case 6:
                if(view.getData().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Data Invalida");
                    view.setData();
                }
                break;
            case 7:
                if(view.getHoraInicio().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Hora Invalida");
                    view.setHoraInicio();
                }
                break;
            case 8:
                if(view.getHoraFim().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Hora Invalida");
                    view.setHoraFim();
                }
                break;
        }
    }
}