package sistema.view;

import sistema.Exeptions.EventoNaoEncontradoException;
import sistema.model.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

//Controller do Menu
public class ViewMenuController {
	private ViewMenu view;
	private Model model;

	//Metodo Inicializador
	public void initViewMenuController(Model model, ViewMenu view) {
		this.model = model;
		this.view = view;
	}

	//Metodo de interacao com a view
	public void interacao(int caso) throws IOException {
		switch (caso) {
			 case 1://Mostra a lista de eventos existentes
				 Map<String,String> eventos = new HashMap<>();
				 eventos = model.mostrarEventos();
				 int x = 1;
				 System.out.println();
				 for (Map.Entry<String,String> evento : eventos.entrySet()) {
					 System.out.println(x + " - " + evento.getValue());
					 x++;
				 }
				 System.out.println();
				view.menu();
				break;
			case 2: view.goPerfil();break; //Vai para a tela de perfil
			case 3: view.goCriarEvento(); break; //Vai para a tela de criacao de evento
			case 4://Pesquisa um evento
				try {
					view.pesquisarEvento();
				}catch (EventoNaoEncontradoException e) {
                    System.out.println(e.getMessage());
					view.menu();
                }
                break;
			case 5: view.goLogin(model); break;//Volta para a tela de login
			case 6: view.menu(); break;//Abre a interface da view
			case 7: view.goEvento(); break; //Vai para um evento selecionado
			case 8:
				view.mensagem("");//Avisa caso uma operacao ilegal seja feita
				view.mensagem("Opcao Invalida!");
				view.mensagem("");
				view.menu();
				break;

		}
	}
}
