package sistema.view;

import java.io.IOException;
import java.util.Scanner;

import sistema.model.*;

//Tela de criacao de uma nova senha
public class ViewNovaSenha {
	private ViewNovaSenhaController controller;
	private Model model;
	private String senha1, senha2, email;

	//inicializa
	public void initViewNovaSenha(Model model) throws IOException {
		this.model = model;
		controller = new ViewNovaSenhaController();
		controller.initViewNovaSenhaController(model, this);
		controller.interacao(4);
	}

	//Cria a interface
	public void menu() throws IOException {
		Scanner sc = new Scanner(System.in);
		String  escolha;
		System.out.println("Esqueceu Sua Senha?");
		System.out.println("1 - Criar Nova Senha");
		System.out.println("2 - Voltar");
		switch (escolha = sc.nextLine()) {
			case "1": controller.interacao(5); break;
			case "2": controller.interacao(2); break;
			default: controller.interacao(3); break;
		}
		sc.close();
	}

	//Recebe a nova senha
	public void novaSenha() throws IOException { // Interaçao 1
		Scanner sc = new Scanner(System.in);
		controller.interacao(1);
		sc.close();
	}

	//Vai para o login
	public void goLogin() throws IOException {
		ViewLogin viewLogin = new ViewLogin();
		viewLogin.initViewLogin(model);
	}

	//mostra na tela uma mensagem, requistado pelo controller
	public void mensagem(String mensagem) {
		System.out.println(mensagem);
	}

	public void setSenha1() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite sua Senha: ");
		senha1 = sc.nextLine();
		controller.interacao(6);
	}

	public void setSenha2() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite sua Senha: ");
		senha2 = sc.nextLine();
		controller.interacao(7);
	}

	public void setEmail() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu Email: ");
		email = sc.nextLine();
		controller.interacao(8);
	}

	public String getEmail() {
		return email;
	}

	public String getSenha1() {
		return senha1;
	}

	public String getSenha2() {
		return senha2;

	}
}
