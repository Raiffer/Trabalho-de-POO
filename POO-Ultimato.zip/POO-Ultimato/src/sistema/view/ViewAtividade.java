package sistema.view;

import sistema.model.*;

import java.io.IOException;
import java.util.Scanner;

//Tela da Atividade Selecionada, mostra o nome da atividade e permite que voce volte para a tela de Atividade
public class ViewAtividade {
	private Model model;
	private ViewAtividadeController controller;
	private String email ,atividade, evento;

	//Inicializa a tela Atividade
	public void initViewAtividade (Model model, String email,String atividade, String evento) throws IOException {// Inicia a instancia da Tela de Atividade.
		this.model = model;
		this.email = email;
		this.atividade = atividade;
		this.evento = evento;
		controller = new ViewAtividadeController();
		controller.initViewAtividadeController(model, this);
		controller.interacao(1);
	}

	//Parte grafica da tela Atividade
	public void menu() throws IOException {
		Scanner sc = new Scanner(System.in);
		String escolha;
		System.out.println("Oque deseja fazer?");
		System.out.println("Atividade: " + atividade);
		System.out.println("2 - Voltar");
		escolha = sc.nextLine();
		switch (escolha) {
			case "2":
				controller.interacao(2); break;
			default:
				controller.interacao(3);
		}
	}

	//Direciona o codigo devolta para a tela do Evento
	public void goEvento() throws IOException {
		ViewEvento view = new ViewEvento();
		view.initViewEvento(email, model, evento);
	}

	//Vai para a tela de criacao de atividade
	public void goCriarAtividade() throws IOException {
		ViewCriarAtividade view = new ViewCriarAtividade();
		view.initViewCriarAtividade( model,  email,  evento);
	}

	//mostra na tela uma mensagem, requistado pelo controller
	public void mensagem(String mensagem) {
		System.out.println(mensagem);
	}

	public String getEvento() {
		return evento;
	}

	public String getEmail(){
		return email;
	}
}
