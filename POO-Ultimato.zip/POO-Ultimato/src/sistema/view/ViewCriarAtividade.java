package sistema.view;

import java.io.IOException;
import java.util.Scanner;

import sistema.model.*;

//Tela de criacao de uma nova atividade
public class ViewCriarAtividade {
	private ViewCriarAtividadeController controller;
	private Model model;
	private String email, nome, data, horaInicio, horaFim, evento;

	//Inicializa o objeto
	public void initViewCriarAtividade(Model model, String email, String evento) throws IOException {
		this.model = model;
		this.email = email;
		this.evento = evento;
		controller = new ViewCriarAtividadeController();
		controller.initViewCriarAtividadeController(model, this);
		controller.interacao(0);
	}

	//Mostra a interface
	public void menu() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Criar Atividade?");
		System.out.println("1 - Criar Atividade");
		System.out.println("2 - Voltar");
		String opcao = sc.nextLine();
		switch (opcao) {
			case "1":
				controller.interacao(1);
				break;
			case "2":
				controller.interacao(2);
				break;
			default:
				controller.interacao(3);
				break;
		}
	}

	//Recebe os dados da Atividade
	public void criarAtividade() throws IOException {
		controller.interacao(4);
	}

	public void setNome() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o Nome da Atividade: ");
		nome = sc.nextLine();
		controller.interacao(5);

	}

	public void setData() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a data da Atividade: ");
		data = sc.nextLine();
		controller.interacao(6);
	}

	public void setHoraInicio() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a hora do inicio da Atividade: ");
		horaInicio = sc.nextLine();
		controller.interacao(7);
	}

	public void setHoraFim() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a hora do fim da Atividade: ");
		horaFim = sc.nextLine();
		controller.interacao(8);
	}

	public void goEvento() throws IOException {
		ViewEvento viewEvento = new ViewEvento();
		viewEvento.initViewEvento(email, model, evento);
	}

	//mostra na tela uma mensagem, requistado pelo controller
	public void mensagem(String mensagem) {
		System.out.println(mensagem);
	}

	public String getEmail() {
		return email;
	}

	public String getNome() {
		return nome;
	}

	public String getData() {
		return data;
	}

	public String getHoraInicio() {
		return horaInicio;
	}

	public String getHoraFim() {
		return horaFim;
	}

	public String getEvento() {
		return evento;
	}
}


