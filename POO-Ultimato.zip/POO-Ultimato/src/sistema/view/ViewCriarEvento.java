package sistema.view;

import java.io.IOException;
import java.util.Scanner;

import sistema.Exeptions.EventoNaoEncontradoException;
import sistema.model.*;

//Tela de criacao de um novo evento
public class ViewCriarEvento {
    private Model model;
    private ViewCriarEventoController controller;
    private String email, nome, local, dataInicio, dataFim;

    //Inicializa o objeto
    public void initViewCriarEvento(Model model, String email) throws IOException{
        this.model = model;
        this.email = email;
        controller = new ViewCriarEventoController();
        controller.initViewCriarEventoController(model, this);
        controller.interacao(1);
    }

    //Abre a interface da tela
    public void menu() throws IOException {
        Scanner sc = new Scanner(System.in);
        String escolha;
        System.out.println("1 - Criar Evento");
        System.out.println("2 - Voltar ");
        escolha = sc.nextLine();
        switch (escolha) {
            case "1":
                controller.interacao(2);
                break;
            case "2":
                controller.interacao(3);
                break;
            default:
                controller.interacao(4);
                break;
        }
    }

    //Recebe as credenciais do evento
    public void criarEvento() throws IOException{
        controller.interacao(5);
    }

    //Volta para a tela de menu
    public void goMenu() throws IOException{
        System.out.println("Bem Vindo ao SEGEA!");
        ViewMenu viewMenu = new ViewMenu();
        viewMenu.initViewMenu(this.email, this.model);
    }

    //mostra na tela uma mensagem, requistado pelo controller
    public void mensagem(String mensagem) {
        System.out.println(mensagem);
    }

    public void setNome() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o nome do evento: ");
        nome = sc.nextLine();
        controller.interacao(6);
    }

    public void setLocal() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o local do evento: ");
        local = sc.nextLine();
        controller.interacao(7);
    }

    public void setDataInicio() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a data de Inicio do evento: ");
        dataInicio = sc.nextLine();
        controller.interacao(8);
    }

    public void setDataFim() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a data de Fim do evento: ");
        dataFim = sc.nextLine();
        controller.interacao(9);
    }
    public String getEmail() throws IOException {
        return this.email;
    }

    public String getLocal() throws IOException {
        return this.local;
    }

    public String getDataInicio() throws IOException {
        return this.dataInicio;
    }

    public String getDataFim() throws IOException {
        return this.dataFim;
    }

    public String getNome() throws IOException {
        return this.nome;
    }

}
