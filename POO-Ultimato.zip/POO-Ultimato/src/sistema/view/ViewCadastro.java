package sistema.view;

import java.io.IOException;
import java.util.Scanner;

import sistema.Exeptions.EmailInvalidoException;
import sistema.model.*;
import sistema.utilidades.EmailValidator;

//Tela de Cadastro de Usuario
public class ViewCadastro {
	private ViewCadastroController controller;
	private Model model;
	private String email, nome, cep, cpf, senha, dataNascimento, telefone;

	//Metodo inicializador da tela de Cadastro
	public void initViewCadastro(Model model) throws IOException {
		this.model = model;
		controller = new ViewCadastroController();
		controller.initViewCadastroController(model, this);
		controller.interacao(4);
	}

	//Metodo que abre a interface da tela de cadastro
	public void menu() throws IOException {
		Scanner sc = new Scanner(System.in);
		int escolha;
		System.out.println("Cadastrar Novo Usuario?");
		System.out.println("1 - Cadastrar Usuario");
		System.out.println("2 - Voltar");
		escolha = sc.nextInt();
		switch (escolha) {
			case 1: controller.interacao(3); break;
			case 2: controller.interacao(2); break;
			default: controller.interacao(5); break;
		}
		sc.close();
	}

	//Metodo que pede as credencias do usuario
	public void cadastrar() throws IOException{ // Interaçao 1
		controller.interacao(1);
	}

	//Redireciona o usuario para a tela de login
	public void goLogin() throws IOException {
		ViewLogin viewLogin = new ViewLogin();
		viewLogin.initViewLogin(model);
	}


	public String getEmail() {
		return email;
	}

	public void setEmail() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu Email: ");
		email = sc.nextLine();
		controller.interacao(7);
	}

	public void setNome() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu nome: ");
		nome = sc.nextLine();
		controller.interacao(10);

	}


	public void setData() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite sua data de nascimento: ");
		dataNascimento = sc.nextLine();
		controller.interacao(11);
	}

	public void setCep() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu CEP: ");
		cep = sc.nextLine();
		controller.interacao(12);
	}
	public void setCpf() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu CPF: ");
		cpf = sc.nextLine();
		controller.interacao(6);
	}

	public void setTelefone() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu Telefone: ");
		telefone = sc.nextLine();
		controller.interacao(9);


	}

	public void setSenha() throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite sua Senha: ");
		senha = sc.nextLine();
		controller.interacao(8);
	}


	public String getNome() {
		return nome;
	}

	public String getCep() {
		return cep;
	}

	public String getCpf() {
		return cpf;
	}

	public String getSenha() {
		return senha;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public String getTelefone() {
		return telefone;
	}

	//mostra na tela uma mensagem, requistado pelo controller
	public void mensagem(String mensagem) {
		System.out.println(mensagem);
	}

}
