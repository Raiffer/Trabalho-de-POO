package sistema.view;

import sistema.model.Model;

import java.io.IOException;

//Metodo que manipulacao da tela de atividade
public class ViewAtividadeController {
	private Model model;
	private ViewAtividade view;

	//inicializador do controller
	public void initViewAtividadeController(Model model, ViewAtividade view) {
		this.model = model;
		this.view = view;
		
	}

	//metodo que interaje com a tela de Atividade
	public void interacao(int caso) throws IOException {
		switch (caso){
			case 1: // Opcao que inicializa a tela de menu de Atividade
				view.menu();
				break;
			case 2: //Opcao q retorna para a tela do envento
				view.goEvento();
				break;
			case 3: //Opcao que avisa caso o usuario utilize uma entrada errada
				view.mensagem("");
				view.mensagem("Opcao Invalida!");
				view.mensagem("");
				break;
			case 4: //vai para a opcao de criar atividade
				view.goCriarAtividade();
		}
	}

}