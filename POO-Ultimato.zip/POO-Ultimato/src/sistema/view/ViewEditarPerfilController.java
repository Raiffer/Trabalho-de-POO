package sistema.view;

import sistema.model.*;

import java.io.IOException;

//Controller da tela de editar Perfil
public class ViewEditarPerfilController {
	private ViewEditarPerfil view;
	private Model model;

	//Inicia o objeto
	public void initViewEditarPerfilController(Model model, ViewEditarPerfil view) {
		this.view = view;
		this.model = model;
	}

	//Metodo que interaje com a view
	public void interacao(int caso) throws IOException {
		switch (caso) {
			case 1: view.menu(); break;//Abre a interface
			case 2:
				view.mudarEmail();
				view.goPerfil();
				break;
			case 3:
				view.mudarNome();
				view.goPerfil();
				break;
			case 4:
				view.mudarSenha();
				view.goPerfil();
				break;
			case 5:
				view.mudarCep();
				view.goPerfil();
				break;
			case 6:
				view.mudarTelefone();
				view.goPerfil();
				break;
			case 7:
				view.goPerfil();
				break;
			case 8:
				view.mensagem("");//Avisa caso uma operacao ilegal seja feita
				view.mensagem("Opcao Invalida!");
				view.mensagem("");
				view.menu();
				break;
		}
	}
}
