package sistema.view;

import sistema.Exeptions.AtividadeNaoEncontradaException;
import sistema.model.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

//Classe controller da tela do evento
public class ViewEventoController {
	private ViewEvento view;
	private Model model;

	//Metodo inicializador do objeto
	public void initViewEventoController(Model model, ViewEvento view) {
		this.view = view;
		this.model = model;
	}

	//Metodo que ira interagir com a view
	public void interacao(int caso) throws IOException{
		switch (caso) {
		case 1:
			//Decide qual interface deve ser exibida
			System.out.println("Usuario Logado: " + view.getEmail());
			System.out.println("Organizador: " + model.getOrganizador(view.getEvento()));
			if (view.getEmail().equals(model.getOrganizador(view.getEvento()))) {
				view.menuOrg();
			}else if (model.verificarParticipante(view.getEmail(),view.getEvento())) {
				view.menuPart();
			}else {
				view.menu();
			}
			break;
		case 2://Entra no evento
			model.entrarEvento(view.getEmail(),view.getEvento());
			view.menuPart();
			break;
		case 3://Permite que o usuario acesse uma tela de um evento
			try {
				view.pesquisarAtividade();
			}catch (AtividadeNaoEncontradaException e) {
				System.out.println(e.getMessage());
				view.menu();
			}
			break;
		case 4://Vai para a tela de criar atividade
			view.goCriarAtividade();
			break;
		case 5://Deleta o evento
			model.removerEvento(view.getEvento());
			view.goMenu();
			break;
		case 6: view.goMenu(); break; //Volta para o menu do sistema
		case 7://Faz uma lista de todas as atividades do evento
			Map<String,String> atividades = new HashMap<>();
			atividades = model.mostrarAtividades();
			int x = 1;
			System.out.println();
			for (Map.Entry<String,String> evento : atividades.entrySet()) {
				System.out.println(x + " - " + evento.getValue());
				x++;
			}
			System.out.println();
			interacao(1);
			break;
		case 8:
			view.mensagem("");//Avisa caso uma operacao ilegal seja executada
			view.mensagem("Opcao Invalida!");
			view.mensagem("");
			interacao(1);
			break;
		case 9:
			view.goAtividade();//abre a atividade selecionada
		}
	}
}
