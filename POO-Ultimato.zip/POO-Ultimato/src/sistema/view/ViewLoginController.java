package sistema.view;

import sistema.Exeptions.EmailInvalidoException;
import sistema.Exeptions.EventoNaoEncontradoException;
import sistema.model.*;

import java.io.IOException;

//Classe controller da tela de login
public class ViewLoginController {

    private ViewLogin view;
    private Model model;

    //Inicializa o objeto
    public void initViewLoginController(Model model, ViewLogin view){
        this.model = model;
        this.view = view;
    }

    //Interaje com a View
    public void interacao(int caso) throws IOException {
        switch (caso){
            case 1://Verifica o usuario
                if(model.verificarUsuario(view.getEmail(), view.getSenha())){
                    view.mensagem("Usuario verificado");
                    view.goMenu(view.getEmail());
                }else{
                    view.mensagem("");//Avisa caso algum dado esteja incorreto
                    view.mensagem("Login ou senha Invalida");
                    view.mensagem("");
                    view.menu();
                }
                break;
            case 2://Vai para a tela de cadastro
                view.goCadastro();
                break;
            case 3://Vai para a tela de redefinir senha
                view.goRedefinirSenha();
                break;
            case 4://abre a interface
                view.menu();
                break;
            case 5:
                view.mensagem("Opcao Invalida! - Pressione Enter para continuar.");
                System.in.read();
                view.menu();
                break;
            case 6: view.logar(); break;

        }
    }
}
