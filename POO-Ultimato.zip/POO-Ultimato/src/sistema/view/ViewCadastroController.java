package sistema.view;

import sistema.Exeptions.CpfInvalidoException;
import sistema.Exeptions.EmailInvalidoException;
import sistema.model.Model;
import sistema.utilidades.CPFValidator;
import sistema.utilidades.EmailValidator;
import sistema.utilidades.NumeroValidator;

import java.io.IOException;

//controlador da classe Cadastro
public class ViewCadastroController {
    private ViewCadastro view;
    private Model model;

    //Inicializador da classe
    public void initViewCadastroController(Model model, ViewCadastro view) {
        this.view = view;
        this.model = model;
    }

    //Metodo de Interacao com a View
    public void interacao(int caso) throws IOException {
        switch(caso){
            case 1://Recebe verifica e guarda as informacoes do usuario
                view.setNome();
                view.setEmail();
                view.setSenha();
                view.setCpf();
                view.setTelefone();
                view.setData();
                view.setCep();
                view.mensagem("Usuario Cadastrado com sucesso!");
                model.criarUsuario(view.getEmail(), view.getSenha(), view.getCep(), view.getCpf(),
                            view.getDataNascimento(), view.getNome(),Long.parseLong(view.getTelefone()));
                view.goLogin();
                break;
            case 2://retorna para a pagina de login
                view.goLogin();
                break;
            case 3: view.cadastrar(); break;
            case 4: view.menu(); break;
            case 5:
                view.mensagem("");
                view.mensagem("Opcao Invalida!");
                view.mensagem("");
                view.menu();
                break;
            case 6: //Valida o CPF
                try {
                    verificarCpf();
                } catch (CpfInvalidoException e) {
                    view.mensagem("");
                    view.mensagem(e.getMessage());
                    view.setCpf();
                }
                break;
           case 7: //Valida o Email
                try {
                    verificarEmail();
                } catch (EmailInvalidoException e){
                    view.mensagem("");
                    view.mensagem(e.getMessage());
                    view.setEmail();
                }
                break;
           case 8:
               //Valida a Senha
                if (view.getSenha().length() < 6 || view.getSenha().trim().isEmpty()) {
                    view.mensagem("");
                    view.mensagem("Senha Invalida - Minino 6 Caracteres");
                    view.setSenha();
                }
                break;
           case 9://Valida o telefone
               if(!NumeroValidator.validarNumero(view.getTelefone())){
                   view.mensagem("");
                   view.mensagem("Telefone Invalido");
                   view.setTelefone();
               }
               break;
           case 10://Valida o nome
                if(view.getNome().trim().isEmpty()){
                    view.mensagem("");
                    view.mensagem("Nome Invalido");
                    view.setNome();
                }
                break;
           case 11: //Valida a data de nacimento
               if(view.getDataNascimento().trim().isEmpty()){
                   view.mensagem("");
                   view.mensagem("Data de Nascimento Invalido");
                   view.setData();
               }
               break;
            case 12://Valida o Cep
                if(view.getCep().trim().isEmpty() || view.getCep().length() != 8){
                    view.mensagem("");
                    view.mensagem("CEP Invalido");
                    view.setCep();
                }
        }


    }
    //Chama o metodo utilitario
    private void verificarEmail() throws EmailInvalidoException {
        if(!EmailValidator.verificarEmail(view.getEmail())){
            throw new EmailInvalidoException("Email invalido");
        }
    }

    //Chama o metodo utilitario
    private void verificarCpf() throws CpfInvalidoException {
        if(!CPFValidator.verificarCPF(view.getCpf())){
            throw new CpfInvalidoException("CPF invalido");
        }
    }
}
