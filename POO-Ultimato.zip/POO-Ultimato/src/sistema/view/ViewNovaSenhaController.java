package sistema.view;

import sistema.Exeptions.EmailInvalidoException;
import sistema.model.Model;
import sistema.utilidades.EmailValidator;

import java.io.IOException;

//Controlador de Nova senha
public class ViewNovaSenhaController {
    ViewNovaSenha view;
    Model model;

    //Inicializa
    public void initViewNovaSenhaController(Model model, ViewNovaSenha view) {
        this.view = view;
        this.model = model;

    }

    //Interaje com a view
    public void interacao(int caso) throws IOException {
        switch(caso){
            case 1://Recebe, valida e armazena os dados recebidos
                view.setEmail();
                if (model.verificarEmail(view.getEmail())) {
                    view.setSenha1();
                    view.setSenha2();
                    if (view.getSenha1().equals(view.getSenha2())){
                        model.setSenha(view.getEmail(), view.getSenha1());
                        view.mensagem("Senha Alterada com sucesso!");
                        view.goLogin();
                    } else {
                        view.mensagem("Senhas Imcompativeis");
                        view.novaSenha();
                    }
                }else {
                    view.mensagem("Email Não cadastrado");
                    interacao(1);
                }

                break;
            case 2: view.goLogin();break; //Volta para o login
            case 3:
                view.mensagem("");
                view.mensagem("Opcao Invalida!");//Avisa em caso de erro
                view.mensagem("");
                view.menu();
                break;
            case 4: view.menu(); break; //Abre a interface da view
            case 5: view.novaSenha(); break; //Chama o metodo que ira receber a nova senha
            case 6: //Verifica senha
                if (view.getSenha1().length() < 6 || view.getSenha1().trim().isEmpty()) {
                view.mensagem("");
                view.mensagem("Senha Invalida - Minino 6 Caracteres");
                view.setSenha1();
            }
                break;
            case 7: //Verifica senha
                if (view.getSenha2().length() < 6 || view.getSenha2().trim().isEmpty()) {
                view.mensagem("");
                view.mensagem("Senha Invalida - Minino 6 Caracteres");
                view.setSenha2();
            }
                break;
            case 8: //Verifica email
                try {
                    verificarEmail();
                } catch (EmailInvalidoException e){
                    view.mensagem("");
                    view.mensagem(e.getMessage());
                    view.setEmail();
                }
                break;
        }
    }
    //Chama o metodo verificador de email
    private void verificarEmail() throws EmailInvalidoException {
        if(!EmailValidator.verificarEmail(view.getEmail())){
            throw new EmailInvalidoException("Email invalido");
        }
    }



}