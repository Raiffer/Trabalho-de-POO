package sistema.utilidades;

// verifica se uma string é composta apenas  por numeros
public class NumeroValidator {

    public static boolean validarNumero(String numero) {
        for (char c : numero.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return numero.length() >= 8 && numero.length() <= 11;
    }
}
