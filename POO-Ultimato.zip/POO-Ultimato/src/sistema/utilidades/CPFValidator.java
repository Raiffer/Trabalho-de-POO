package sistema.utilidades;

//Valida um CPF dado
public class CPFValidator {

    public static boolean verificarCPF(String cpf) {
        if (cpf == null || cpf.length() != 11 || !cpf.matches("\\d+")) {
            return false;
        }

        if (cpf.matches("(\\d)\\1{10}")) {
            return false;
        }

        try {
            int sum = 0;
            for (int i = 0; i < 9; i++) {
                sum += (cpf.charAt(i) - '0') * (10 - i);
            }
            int firstVerifier = 11 - (sum % 11);
            if (firstVerifier == 10 || firstVerifier == 11) {
                firstVerifier = 0;
            }


            if (firstVerifier != (cpf.charAt(9) - '0')) {
                return false;
            }

            sum = 0;
            for (int i = 0; i < 10; i++) {
                sum += (cpf.charAt(i) - '0') * (11 - i);
            }
            int secondVerifier = 11 - (sum % 11);
            if (secondVerifier == 10 || secondVerifier == 11) {
                secondVerifier = 0;
            }

            return secondVerifier == (cpf.charAt(10) - '0');

        } catch (NumberFormatException e) {
            return false;
        }
    }

}

